import { ADD_CART_DATA} from "./actionTypes";

export const addCartData =(payload)=>{
    return {
        type:ADD_CART_DATA,
        payload
    }
}